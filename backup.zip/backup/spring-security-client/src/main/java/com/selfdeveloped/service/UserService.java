package com.selfdeveloped.service;

import com.selfdeveloped.entity.User;
import com.selfdeveloped.model.UserModel;

public interface UserService {

	User registerUser(UserModel userModel);

	void saveVerificationTokenForUser(String token, User user); 

}
 
